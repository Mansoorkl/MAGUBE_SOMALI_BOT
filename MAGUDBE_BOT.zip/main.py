
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters

import os

TOKEN = os.getenv("TOKEN")  # Use environment variable for security

USER_PREFERENCES = {}  # Store user preferences like gender and mode

# Default welcome message
WELCOME_MESSAGE = "Kusoo dhawoow Magudbe bot! Waxaan kaa dhigaynaa xirfadle ka xamaasha saaxada shukaansiga 🙌"

# Gender-specific responses
def get_response(text, gender, mode):
    text = text.lower()
    if mode == "kaftan":
        return "😂 Kaftan: Haddii jacaylka laga helo Amazon, waxaan kuu dalbayaa 'Prime Love'!"
    elif mode == "dheer":
        if "jacayl" in text:
            return "Jacaylka dhabta ah wuxuu u baahan yahay ixtiraam, kalsooni, iyo waqtigaaga. U fiirso waxa qalbigaagu dareemayo."
        elif "gabar" in text or "naag" in text:
            return "Gabadh si edeb leh ula hadal. Bilow salaanta, ka dib si xushmad leh u wado sheekada."
        elif "wiil" in text:
            return "Wiil wanaag badan waa mid fahmo, dulqaad leh, oo daacad u ah xiriirka."
        else:
            return "Xiriir wanaagsan wuxuu u baahan yahay is-faham iyo daacadnimo. Maxaad rabtaa inaad ka ogaato?"
    else:  # gaaban
        if "jacayl" in text:
            return "Jacayl = Kalsooni + Xushmad ❤️"
        elif "gabar" in text or "naag" in text:
            return "Gabadh si edeb leh ula hadal."
        elif "wiil" in text:
            return "Wiil daacad ah = xiriir wanaagsan."
        else:
            return "Weydii wax kale xiriirka ah."

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("Wiil ayaan ahay", callback_data='set_gender_wiil')],
        [InlineKeyboardButton("Gabar ayaan ahay", callback_data='set_gender_gabar')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(WELCOME_MESSAGE, reply_markup=reply_markup)

async def set_gender(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id
    await query.answer()

    if query.data == 'set_gender_wiil':
        USER_PREFERENCES[user_id] = {'gender': 'wiil', 'mode': 'gaaban'}
        await query.edit_message_text("✅ Waxaad dooratay: Wiil
Dooro nooca jawaabta aad rabto:", reply_markup=mode_keyboard())
    elif query.data == 'set_gender_gabar':
        USER_PREFERENCES[user_id] = {'gender': 'gabar', 'mode': 'gaaban'}
        await query.edit_message_text("✅ Waxaad dooratay: Gabar
Dooro nooca jawaabta aad rabto:", reply_markup=mode_keyboard())
    elif query.data.startswith('mode_'):
        mode = query.data.split("_")[1]
        if user_id in USER_PREFERENCES:
            USER_PREFERENCES[user_id]['mode'] = mode
        await query.edit_message_text(f"✅ Waxaad dooratay: {mode.capitalize()} mode
Weydii su’aashaada hadda.")

def mode_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("Jawaab Gaaban", callback_data='mode_gaaban')],
        [InlineKeyboardButton("Jawaab Dheer", callback_data='mode_dheer')],
        [InlineKeyboardButton("Kaftan", callback_data='mode_kaftan')],
    ])

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_text = update.message.text
    prefs = USER_PREFERENCES.get(user_id, {'gender': 'wiil', 'mode': 'gaaban'})
    response = get_response(user_text, prefs['gender'], prefs['mode'])
    await update.message.reply_text(response)

def main():
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(set_gender))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    print("✅ MAGUDBE Bot is running...")
    app.run_polling()

if __name__ == "__main__":
    main()
